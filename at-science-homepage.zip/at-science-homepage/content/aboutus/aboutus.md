
ATProto Science is an initiative aimed at fostering an ecosystem for science on ATProto — developing tools, communities, and infrastructure for publishing, curation, data sharing, and social discourse around research. We also organize events and workshops to bring the community together.

## Themes & Interests

We interpret science broadly — not just traditional academic research, but any form of systematic inquiry, including work by citizen scientists, independent researchers, and self-defined scholars. We're exploring a range of approaches to building this inclusive research ecosystem on ATProto:

- New kinds of science publishing and communication tools (such as Nanopublications or Discourse Graphs)
- ATProto lexicon design for scholarly activity
- Social apps for research communities
- Discovery and curation through better research feeds
- AI applications for scientific work
- ATProto integrations for tools for thought like Obsidian, Notion or Roam.
- Decentralized infrastructure for hosting science data and services

This is an evolving space, and we're actively learning from the community about what tools and services would be most valuable for research on Bluesky/ATProto. Please join the discussion!
