Site structure & content at a glance

* home page
	* content - see [[index]]
		* main message: 
			* potential of atproto for science, and science for atproto
			* this is a movement, get on board
		* browse the site
		* vancouver 2026: registration and call for ideas open (link)
		* top general FAQs
* event menu - see [[events]]
	* vancouver event - content december 2025 - see [[event-atmosphere2026]]
		* Register for the event and submit 
		* The call for presentations and panels is open
		* You cnan also
		* form
* projects - [[projects]]
* people - see [[People]]
	* include a paragraph only for people speaking at the event or who have a project in Projects
* [[FAQs]] 
	* two classes: general, vancouver 2026
	* note: if adding a 4th preview item for FAQs to the homepage is a problem, the FAQs could simply appear at the bottom of the home page and unscroll as required
